import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-ngx-csv-parser',
  template: `
    <p>
      ngx-csv-parser works!
    </p>
  `,
  styles: []
})
export class NgxCsvParserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
