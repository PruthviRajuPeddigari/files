# NgxCsvParser - v0.0.7 (26/02/2021)
* New Features:
* Case insensitive check for csv file extension

# NgxCsvParser - v0.0.6 (01/08/2020)
* New Features:
* Fix undefined issue for the header

# NgxCsvParser - v0.0.5 (27/07/2020)
* New Features:
* Compliance updated as per RFC 4180
* RFC 4180 https://tools.ietf.org/html/rfc4180

# NgxCsvParser - v0.0.4 (27/07/2020)
* New Features:
* Compliance added as per RFC 4180
* RFC 4180 https://tools.ietf.org/html/rfc4180
* Not CSV Files can have values containing (,) and other characters as per RFC 4180

# NgxCsvParser - v0.0.3 (05/06/2020)
* New Features:
* Dependencies updated

# NgxCsvParser - v0.0.2 (04/12/2019)
* New Features:
* README File updated

# NgxCsvParser - v0.0.1 (04/12/2019)
* New Features:
* README File updated

# NgxCsvParser - v0.0.0 (04/12/2019)
* New Features:
* CSV File parsing support for Angular Framework. Go through the README.md file for detailed features and documentation.